<?php

namespace App\Http\Controllers;

use App\Models\Animais;
use Illuminate\Http\Request;

class AnimaisController extends Controller
{
    public function create(Request $request){
        $items = new Animais();
        $items->nome = $request->nome;
        $items->especie = $request->especie;
        $items->peso = $request->peso;
        $items->save();
        return 'create';
    }

    public function read()
    {
    return Animais::all();
    }

    public function update(Request $request)
    {
    $items = Animais::findorfail($request->id);
    $items->nome = $request->nome;
    $items->especie = $request->especie;
    $items->peso = $request->peso;
    $items->update();
    return 'update';
    }
    public function delete(Request $request)
    {
    $items = Animais::findorfail($request->id)->delete();
    return 'delete';
    }
}

